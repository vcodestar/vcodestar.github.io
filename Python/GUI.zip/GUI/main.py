import pymysql
import tkinter as tk
from PIL import Image, ImageTk

conn = pymysql.connect(
    host='localhost',
    user='root',
    password='7m8jSC25',
    database='ex1'
)

team_names = [
    "Hawks", "Celtics", "Nets", "Hornets",
    "Bulls", "Cavaliers", "Mavericks", "Nuggets",
    "Pistons", "Warriors", "Rockets", "Pacers",
    "Clippers", "Lakers", "Grizzlies", "Heat",
    "Bucks", "Timberwolves", "Pelicans", "Knicks",
    "Thunder", "Magic", "76ers", "Suns",
    "Trail Blazers", "Kings", "Spurs", "Raptors",
    "Jazz", "Wizards"
]


team_names = sorted(team_names)

def resize_image(image_path, width, height):
    original_image = Image.open(image_path)
    resized_image = original_image.resize((width, height), Image.ANTIALIAS)
    return ImageTk.PhotoImage(resized_image)

def fetch_team_data(team_name):
    cursor = conn.cursor()

    query = f"""
        SELECT game_id, home_team_wins
        FROM games
        JOIN teams ON games.home_team_id = teams.team_id
        WHERE nickname = '{team_name}'

        UNION

        SELECT game_id, 0
        FROM games
        JOIN teams ON games.visitor_team_id = teams.team_id AND home_team_wins = 1
        WHERE nickname = '{team_name}'

        UNION

        SELECT game_id, 1
        FROM games
        JOIN teams ON games.visitor_team_id = teams.team_id AND home_team_wins = 0
        WHERE nickname = '{team_name}';
    """

    cursor.execute(query)
    result = cursor.fetchall()

    columns = [col[0] for col in cursor.description]
    print(columns)

    for row in result:
        print(row)

    query_players = f"select distinct nickname, player_name from players join teams on players.team_id = teams.team_id where nickname = '{team_name}';"
    cursor.execute(query_players)
    result_players = cursor.fetchall()

    columns_players = [col[0] for col in cursor.description]
    print(columns_players)

    count = 0

    for row_players in result_players:
        team, player_name = row_players
        count +=1
        print(f"Team: {team}, Player Name: {player_name}")

    print(count)

    conn.close()

def on_button_click(team_name, root):
    fetch_team_data(team_name)
    root.destroy()


def main():
    root = tk.Tk()
    root.title("Team Names GUI")


    root.configure(bg='black')


    team_logos = [
        resize_image(f"{team_names[i]}.png", 150, 60) if i < len(team_names) else None
        for i in range(len(team_names))
    ]

    for i, team_name in enumerate(team_names):

        button_image = team_logos[i] if team_logos[i] else None

        button = tk.Button(
            root,
            text=team_name,
            image=button_image,
            compound=tk.TOP,
            width=150,
            height=70,
            command=lambda name=team_name, r=root: on_button_click(name, r)
        )
        button.grid(row=i // 3, column=i % 3, padx=220, pady=10)

    root.state('zoomed')

    root.mainloop()


if __name__ == "__main__":
    main()

